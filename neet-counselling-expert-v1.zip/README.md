# NEET Counselling Expert 2026

Mobile-first prototype for NEET UG counselling tools.

## Included
- Homepage
- College predictor prototype
- Cutoff explorer
- College search
- Preference-list module placeholder
- MCC/state counselling module placeholder
- Responsive design

## Important
The included cutoff/rank values are **prototype/demo data only**. Replace them with verified official counselling data before production.

## Run
This is a static HTML/CSS/JS prototype and can be opened directly in a browser or deployed on a static host.
