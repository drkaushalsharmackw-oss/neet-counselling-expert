const colleges = [
  {name:"AIIMS New Delhi", state:"Delhi", type:"Government", quota:"AIQ", cutoff:57, fees:"Low"},
  {name:"SMS Medical College Jaipur", state:"Rajasthan", type:"Government", quota:"State/AIQ", cutoff:850, fees:"Low"},
  {name:"Dr. SN Medical College Jodhpur", state:"Rajasthan", type:"Government", quota:"State/AIQ", cutoff:2600, fees:"Low"},
  {name:"RNT Medical College Udaipur", state:"Rajasthan", type:"Government", quota:"State/AIQ", cutoff:3200, fees:"Low"},
  {name:"JLN Medical College Ajmer", state:"Rajasthan", type:"Government", quota:"State/AIQ", cutoff:4100, fees:"Low"},
  {name:"GMC Kota", state:"Rajasthan", type:"Government", quota:"State/AIQ", cutoff:4700, fees:"Low"}
];

const app = document.querySelector("#app");

function header(){
  return `<header class="topbar">
    <div class="brand"><span class="brand-mark">NE</span><div><strong>NEET Counselling</strong><small>EXPERT 2026</small></div></div>
    <nav>
      <a href="#home">Home</a><a href="#predictor">College Predictor</a><a href="#cutoffs">Cutoffs</a><a href="#colleges">Colleges</a><a href="#tools">Tools</a>
    </nav>
    <button class="login" onclick="alert('Login module will be connected to secure authentication in the next phase.')">Login</button>
  </header>`;
}

function home(){
 return `<section id="home" class="hero">
   <div class="hero-copy"><span class="pill">NEET UG COUNSELLING • 2026</span>
   <h1>Make your NEET counselling decisions with confidence.</h1>
   <p>Explore colleges, analyse previous cutoffs, build your preference list and prepare for counselling rounds.</p>
   <div class="actions"><a class="btn primary" href="#predictor">Start College Predictor →</a><a class="btn ghost" href="#colleges">Explore Colleges</a></div>
   <div class="trust"><span>✓ College-wise data</span><span>✓ AIQ & State counselling</span><span>✓ Mobile friendly</span></div></div>
   <div class="hero-card"><div class="score">2026</div><h3>Counselling Dashboard</h3><div class="mini-row"><b>College Predictor</b><span>Ready</span></div><div class="mini-row"><b>Cutoff Analysis</b><span>Explore</span></div><div class="mini-row"><b>Preference List</b><span>Build</span></div></div>
 </section>
 <section class="section"><div class="section-head"><div><span class="eyebrow">TOOLS</span><h2>Everything you need in one place</h2></div></div>
 <div class="grid four">
 ${card("🎯","College Predictor","Estimate colleges from rank, category, state and quota.","#predictor")}
 ${card("📊","Cutoff Analysis","Compare previous closing ranks and counselling trends.","#cutoffs")}
 ${card("🏥","College Explorer","Search government and private medical colleges.","#colleges")}
 ${card("📝","Preference List","Create and organise your counselling choices.","#tools")}
 </div></section>`;
}
function card(icon,title,text,href){return `<a class="feature" href="${href}"><span class="icon">${icon}</span><h3>${title}</h3><p>${text}</p><span class="arrow">Open →</span></a>`}

function predictor(){
 return `<section id="predictor" class="section page"><span class="eyebrow">COLLEGE PREDICTOR</span><h2>Find colleges matching your NEET profile</h2><p class="muted">Demo dataset for the prototype. Verified 2026 counselling data will be added before production.</p>
 <div class="panel"><div class="form-grid">
 <label>NEET AIR<input id="rank" type="number" placeholder="e.g. 2500"></label>
 <label>Category<select id="category"><option>General</option><option>OBC</option><option>SC</option><option>ST</option><option>EWS</option></select></label>
 <label>Preferred state<select id="state"><option>Any State</option><option>Rajasthan</option><option>Delhi</option></select></label>
 <label>Quota<select id="quota"><option>AIQ</option><option>State Quota</option></select></label>
 </div><button class="btn primary" onclick="runPredictor()">Predict Colleges</button></div>
 <div id="results"></div></section>`;
}

function runPredictor(){
 const rank=Number(document.querySelector("#rank").value);
 const state=document.querySelector("#state").value;
 const matches=colleges.filter(c=>(!state||state==="Any State"||c.state===state) && (!rank||rank<=c.cutoff*1.7)).sort((a,b)=>a.cutoff-b.cutoff);
 document.querySelector("#results").innerHTML = `<div class="result-title">${matches.length} prototype matches</div>`+
 (matches.length?matches.map(c=>`<div class="result"><div><strong>${c.name}</strong><p>${c.state} • ${c.type} • ${c.quota}</p></div><span>Previous closing rank: ${c.cutoff}</span></div>`).join(""):`<div class="empty">No prototype match. Try a broader search.</div>`);
}

function cutoffs(){
 return `<section id="cutoffs" class="section page"><span class="eyebrow">CUTOFF ANALYSIS</span><h2>Previous closing rank explorer</h2><p class="muted">Prototype values only — do not use these figures for actual 2026 choice filling.</p>
 <div class="table-wrap"><table><thead><tr><th>College</th><th>State</th><th>Type</th><th>Previous closing rank</th></tr></thead><tbody>${colleges.map(c=>`<tr><td>${c.name}</td><td>${c.state}</td><td>${c.type}</td><td>${c.cutoff}</td></tr>`).join("")}</tbody></table></div></section>`;
}

function collegesPage(){
 return `<section id="colleges" class="section page"><span class="eyebrow">COLLEGE EXPLORER</span><h2>Explore medical colleges</h2><div class="search"><input id="collegeSearch" placeholder="Search college or state..." oninput="filterColleges()"></div><div id="collegeList" class="grid two">${collegeCards(colleges)}</div></section>`;
}
function collegeCards(list){return list.map(c=>`<article class="college"><div class="college-top"><span class="type">${c.type}</span><span>${c.state}</span></div><h3>${c.name}</h3><p>Quota: ${c.quota}</p><button class="link-btn" onclick="alert('Detailed college profile will be added in the database phase.')">View details →</button></article>`).join("")}
function filterColleges(){const q=document.querySelector("#collegeSearch").value.toLowerCase(); document.querySelector("#collegeList").innerHTML=collegeCards(colleges.filter(c=>(c.name+" "+c.state).toLowerCase().includes(q)))}

function tools(){
 return `<section id="tools" class="section page"><span class="eyebrow">COUNSELLING TOOLS</span><h2>Build your counselling plan</h2><div class="grid two">
 <div class="panel"><h3>Preference List Generator</h3><p class="muted">Select colleges and arrange them in your preferred order.</p><button class="btn primary" onclick="alert('Preference list builder is the next module.')">Open Builder</button></div>
 <div class="panel"><h3>MCC & State Counselling</h3><p class="muted">Central and state counselling information will be organised here.</p><button class="btn ghost" onclick="alert('Counselling information module is being prepared.')">Explore</button></div>
 </div></section>`;
}

function render(){
 app.innerHTML=header()+home()+predictor()+cutoffs()+collegesPage()+tools()+`<footer><strong>NEET Counselling Expert 2026</strong><p>Prototype for counselling education and planning. Always verify official counselling notices before making choices.</p></footer>`;
}
render();
window.runPredictor=runPredictor; window.filterColleges=filterColleges;
